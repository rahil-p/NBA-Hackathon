# Basketball Analytics

In this project, our team evaluated the +/- metrics for each participating player in various NBA games; we applied robust methods while iterating through game and play-by-play data to optimize the reliability of the metric.
