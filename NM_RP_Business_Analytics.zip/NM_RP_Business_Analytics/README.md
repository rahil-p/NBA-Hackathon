NBA Hackathon Business Analytics

Outside Data in team_data.csv :

	Market_Size : media market population (in 1000s) (Source: Reddit, Nielson)

	Championships : number of championships franchise has won (includes previous cities of franchise) up until 2016 (Source: Wikipedia)

	Playoffs : times team has made playoffs from 2000-2016 (Source: Wikipedia)

	Twitter : number of Twitter followers (in millions) of each team in 2016 (Source: Complex)


Models Tried (in analysis directory):

	Best Performing (validation MAPE of 0.256):
	Random Forest
	max_depth=18, random_state=0, criterion='mae', n_estimators=35

	Others Tried:
	Linear Regression
	Decision Tree :
	Naive Bayes
	Support Vector Machine
	Multi-Layer Perceptron
	Ridge Regression
	K Nearest Neighbor Regression

Other Strategy Tried (in analysis2 directory):

	Used game statistics, features to assess day of week, how many games are on the same day, how close the games are. Performed well but ultimately chose first model due to higher cross validation MAPE and more intuitive features.
	Could have also tried ensemble method combining the above model with this.

Process in Business.ipynb:

	- preprocessing and aggregation of data
		add features for temporal/seasonal effects and home/away features from given and outside datasets
	- output clean features

